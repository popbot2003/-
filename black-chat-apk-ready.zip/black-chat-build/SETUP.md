# 🚀 دليل الإعداد السريع - Black Chat

## الخطوة 1️⃣: تثبيت المتطلبات

```bash
# تثبيت المكتبات
npm install

# أو باستخدام yarn
yarn install
```

---

## الخطوة 2️⃣: تشغيل للتطوير

```bash
npm run dev
```

سيفتح التطبيق على: `http://localhost:5173`

---

## الخطوة 3️⃣: البناء للإنتاج

```bash
npm run build
```

سيُنشئ مجلد `dist` جاهز للنشر

---

## الخطوة 4️⃣: بناء APK للـ Android

```bash
# المرة الأولى فقط
npm run cap:add

# كل مرة تريد بناء
npm run cap:build

# ثم
npm run android:build
```

ستجد APK في:
```
android/app/build/outputs/apk/release/app-release.apk
```

---

## 📱 المتغيرات البيئية

**لا تحتاج إلى ملف `.env` لأن:**
- ✅ Supabase URL محفوظة برمجياً
- ✅ API Keys محفوظة في قاعدة البيانات
- ✅ المشروع يحملها تلقائياً

**إذا احتجت لتغيير Supabase:**
افتح `src/config/constants.js` و عدّل:

```javascript
export const SUPABASE_URL = 'YOUR_URL';
export const SUPABASE_KEY = 'YOUR_KEY';
```

---

## ✅ قائمة التحقق

- [ ] تثبيت Node.js 18+
- [ ] تشغيل `npm install`
- [ ] اختبار `npm run dev`
- [ ] تشغيل `npm run build`
- [ ] تثبيت Android Studio (للـ APK)
- [ ] تشغيل `npm run cap:add`
- [ ] بناء APK `npm run android:build`

---

## 🔗 الروابط المهمة

- [Node.js](https://nodejs.org/) - تحميل
- [Android Studio](https://developer.android.com/studio) - التطوير
- [Capacitor](https://capacitorjs.com/docs) - التوثيق
- [Supabase](https://supabase.com/) - قاعدة البيانات

---

## 🎯 الخطوة التالية

**اختر واحد:**

### PWA (تطبيق ويب)
1. شغّل `npm run dev`
2. افتح في المتصفح
3. اضغط "إضافة إلى الشاشة الرئيسية"

### APK (تطبيق أصلي)
1. شغّل `npm run cap:add`
2. شغّل `npm run android:build`
3. ثبّت الملف على الهاتف

---

تم الإعداد! 🎉
