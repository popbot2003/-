# Black Chat - بلاك شات 👿

تطبيق الذكاء الاصطناعي العربي - يعمل على الويب والهاتف

---

## 📱 خيارات التثبيت

### ✅ الخيار الأول: PWA (تطبيق ويب متقدم)
**الأسهل والأسرع** - يعمل على أي هاتف وأي متصفح

#### على Android:
1. افتح المشروع في المتصفح
2. اضغط على القائمة (⋮) وقل: "إضافة إلى الشاشة الرئيسية"
3. تم! سيظهر التطبيق في الشاشة الرئيسية مع الأيقونة 👿

#### على iPhone:
1. افتح المشروع في Safari
2. اضغط مشاركة (مربع مع سهم) → "إضافة إلى الشاشة الرئيسية"
3. تم!

---

### ✅ الخيار الثاني: Android APK (تطبيق أصلي)
**أكثر تطوراً** - أداء أفضل وتثبيت سهل

#### المتطلبات:
```bash
Node.js 18+ 
npm أو yarn
Java Development Kit (JDK 11+)
Android Studio (اختياري)
```

#### خطوات البناء:

**1️⃣ تثبيت المتطلبات:**
```bash
npm install
```

**2️⃣ إضافة منصة Android:**
```bash
npm run cap:add
```

**3️⃣ البناء والنسخ:**
```bash
npm run cap:build
```

**4️⃣ فتح في Android Studio (اختياري):**
```bash
npm run android:open
```

**5️⃣ بناء APK:**

خيار أ - من السطر الأوامر:
```bash
npm run android:build
```
ستجد الملف في: `android/app/build/outputs/apk/release/app-release.apk`

خيار ب - من Android Studio:
- افتح `android` folder في Android Studio
- اضغط Build → Build Bundle(s) / APK(s) → Build APK(s)
- ستجد الملف تحت `Locate`

**6️⃣ تثبيت على الهاتف:**
```bash
adb install android/app/build/outputs/apk/release/app-release.apk
```

أو انسخ الملف APK إلى الهاتف وثبته يدويّاً.

---

## 🚀 التطوير المحلي

```bash
# تشغيل سيرفر التطوير
npm run dev

# الانتقال إلى http://localhost:5173
```

---

## 📦 ملفات التكوين المهمة

| الملف | الوصف |
|------|-------|
| `manifest.json` | بيانات التطبيق والأيقونات |
| `service-worker.js` | يسمح بالعمل بدون إنترنت |
| `capacitor.config.ts` | إعدادات التطبيق الأصلي |
| `package.json` | المتطلبات والسكريبتات |

---

## 🔐 المتغيرات البيئية

المفاتيح (API Keys) محفوظة في قاعدة البيانات (Supabase)
- لا تحتاج إلى ملف `.env` منفصل
- المشروع سيحمل المفاتيح من الدالة الـ backend

---

## ✨ الميزات

✅ تطبيق ويب متقدم (PWA)
✅ يعمل بدون إنترنت (Offline Mode)
✅ تحديثات تلقائية
✅ أيقونة مخصصة 👿
✅ دعم اللغة العربية الكامل
✅ متوافق مع جميع الهواتف

---

## 🐛 استكشاف الأخطاء

**Service Worker غير متسجل:**
```bash
# امسح الـ cache والبيانات:
npm run dev
# ثم افتح DevTools → Application → Clear storage
```

**لا يعمل بدون إنترنت:**
- تأكد من تسجيل Service Worker (DevTools → Application)
- تحقق من أن الصفحة محفوظة في الـ Cache

**APK كبير جداً:**
```bash
npm run android:build -- -PenableProguard=true
```

---

## 📞 الدعم والتطوير

- **لسؤال عن البناء:** اطلب مساعدة من Claude
- **لتحديث الأيقونات:** استبدل `public/icon-*.png`
- **لتغيير الألوان:** عدّل `theme_color` في `manifest.json`

---

## 📄 الترخيص

جميع الحقوق محفوظة © 2024 Black Chat

---

**تم الإعداد بنجاح! 🎉**

اختر الخيار اللي يناسبك:
1. PWA → اتبع خطوات PWA أعلاه
2. APK → اتبع خطوات Android APK أعلاه
