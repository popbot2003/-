const CACHE_NAME = 'black-chat-v1';
const RUNTIME_CACHE = 'black-chat-runtime-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.svg',
  '/icon-192.png',
  '/icon-512.png'
];

// تثبيت Service Worker وحفظ الملفات الأساسية
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(ASSETS_TO_CACHE).catch(err => {
        console.log('بعض الملفات قد لا تكون متاحة:', err);
        return cache.addAll(ASSETS_TO_CACHE.filter(url => url !== '/icon-192.png' && url !== '/icon-512.png'));
      });
    })
  );
  self.skipWaiting();
});

// تنظيف النسخ القديمة
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames
          .filter(name => name !== CACHE_NAME && name !== RUNTIME_CACHE)
          .map(name => caches.delete(name))
      );
    })
  );
  self.clients.claim();
});

// استراتيجية الكاش: Network First للـ API، Cache First للأصول
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);

  // للـ API requests استخدم Network First
  if (url.pathname.includes('/api/') || url.hostname !== location.hostname) {
    event.respondWith(
      fetch(request)
        .then(response => {
          if (response && response.status === 200 && response.type !== 'error') {
            const responseClone = response.clone();
            caches.open(RUNTIME_CACHE).then(cache => {
              cache.put(request, responseClone);
            });
          }
          return response;
        })
        .catch(() => {
          return caches.match(request).then(response => {
            return response || new Response(
              JSON.stringify({ error: 'لا توجد اتصال بالإنترنت' }),
              { status: 503, statusText: 'Service Unavailable' }
            );
          });
        })
    );
    return;
  }

  // للأصول استخدم Cache First
  event.respondWith(
    caches.match(request).then(response => {
      return response || fetch(request).then(response => {
        if (!response || response.status !== 200) {
          return response;
        }
        const responseClone = response.clone();
        caches.open(RUNTIME_CACHE).then(cache => {
          cache.put(request, responseClone);
        });
        return response;
      }).catch(() => {
        return caches.match('/index.html');
      });
    })
  );
});

// معالجة الرسائل من التطبيق
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
