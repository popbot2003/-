# Black Chat — APK Build

هذا المشروع مجهز ليُبنى إلى APK عبر GitHub Actions، بدون الحاجة إلى Android Studio على جهازك.

## الطريقة
1. ارفع محتويات هذا المجلد إلى مستودع GitHub.
2. افتح تبويب Actions.
3. اختر **Build Black Chat APK**.
4. اضغط **Run workflow**.
5. بعد انتهاء البناء، افتح نتيجة التشغيل ونزّل artifact باسم **black-chat-debug-apk**.
6. فك الضغط وستجد `app-debug.apk`.

ملاحظة: هذه نسخة Debug موقعة تلقائيًا للتثبيت والاختبار على الهاتف. إذا أردت نسخة Release موقعة باسم التطبيق ومفتاح خاص، نجهزها بعد نجاح أول APK.
